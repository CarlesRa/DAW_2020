function paidContent() {
    alert('¡¡Pague al desarrollador si desea que funcione!!')
}