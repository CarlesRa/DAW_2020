import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventoAddRoutingModule } from './evento-add-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EventoAddRoutingModule
  ]
})
export class EventoAddModule { }
