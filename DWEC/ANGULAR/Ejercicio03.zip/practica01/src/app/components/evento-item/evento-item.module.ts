import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventoItemRoutingModule } from './evento-item-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EventoItemRoutingModule
  ]
})
export class EventoItemModule { }
