import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventosShowRoutingModule } from './eventos-show-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EventosShowRoutingModule
  ]
})
export class EventosShowModule { }
