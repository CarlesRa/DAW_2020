import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventoDetailRoutingModule } from './evento-detail-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EventoDetailRoutingModule
  ]
})
export class EventoDetailModule { }
